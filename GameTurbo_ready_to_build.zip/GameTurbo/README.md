# Game Turbo

Android application source project.

## Build APK with GitHub Actions
1. Upload this project folder's contents to a GitHub repository (keep the `.github` folder).
2. Open the repository's **Actions** tab.
3. Select **Build Game Turbo APK** and choose **Run workflow** (or push to `main`/`master`).
4. When the workflow finishes, open the run and download the `GameTurbo-debug-apk` artifact.

The resulting file is a debug APK (`app-debug.apk`).
