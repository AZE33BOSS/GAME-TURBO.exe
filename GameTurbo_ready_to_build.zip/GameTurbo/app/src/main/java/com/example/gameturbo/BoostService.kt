package com.example.gameturbo

import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.graphics.PixelFormat
import android.os.BatteryManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

class BoostService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private var inGame = false
    private var prevFilter = NotificationManager.INTERRUPTION_FILTER_ALL
    private var overlay: TextView? = null
    private var origW = 0
    private var origH = 0
    private var resChanged = false

    private val poll = object : Runnable {
        override fun run() {
            tick()
            handler.postDelayed(this, 1500)
        }
    }
    private val stats = object : Runnable {
        override fun run() {
            updateOverlay()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("turbo", "Game Turbo", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "turbo")
            .setContentTitle("Game Turbo aktivdir")
            .setContentText("Oyun gözlənilir...")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        startForeground(1, n)
        val m = resources.displayMetrics
        val real = android.graphics.Point()
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealSize(real)
        origW = real.x; origH = real.y
        handler.post(poll)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (inGame) exitGame()
        super.onDestroy()
    }

    private fun prefs() = getSharedPreferences("cfg", MODE_PRIVATE)

    private fun foregroundPackage(): String? {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val ev = usm.queryEvents(now - 15000, now)
        val e = UsageEvents.Event()
        var last: String? = null
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.ACTIVITY_RESUMED) last = e.packageName
        }
        return last
    }

    private fun tick() {
        val games = prefs().getStringSet("games", emptySet()) ?: emptySet()
        val pkg = foregroundPackage() ?: return
        val isGame = pkg in games
        if (isGame && !inGame) enterGame(pkg)
        else if (!isGame && inGame && pkg != packageName && pkg != "com.android.systemui") exitGame()
    }

    private fun enterGame(game: String) {
        inGame = true
        val p = prefs()
        if (p.getBoolean("dnd", true)) {
            val nm = getSystemService(NotificationManager::class.java)
            if (nm.isNotificationPolicyAccessGranted) {
                prevFilter = nm.currentInterruptionFilter
                nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_NONE)
            }
        }
        if (p.getBoolean("kill", true)) killBackground(game)
        if (p.getBoolean("res", false)) {
            val scale = p.getInt("scale", 85) / 100f
            val w = (origW * scale).toInt() / 2 * 2
            val h = (origH * scale).toInt() / 2 * 2
            resChanged = runShell("wm size ${w}x$h")
        }
        if (p.getBoolean("overlay", true)) showOverlay()
    }

    private fun exitGame() {
        inGame = false
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.isNotificationPolicyAccessGranted) nm.setInterruptionFilter(prevFilter)
        if (resChanged) { runShell("wm size reset"); resChanged = false }
        hideOverlay()
    }

    private fun killBackground(except: String) {
        val am = getSystemService(ActivityManager::class.java)
        val home = packageManager.resolveActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0
        )?.activityInfo?.packageName
        for (app in packageManager.getInstalledApplications(0)) {
            val system = app.flags and ApplicationInfo.FLAG_SYSTEM != 0
            if (system || app.packageName == except || app.packageName == packageName || app.packageName == home) continue
            am.killBackgroundProcesses(app.packageName)
        }
    }

    // wm size normal tətbiqlər üçün işləmir; yalnız shell/Shizuku icazəsi olduqda.
    private fun runShell(cmd: String): Boolean = try {
        val pr = Runtime.getRuntime().exec(arrayOf("sh", "-c", cmd))
        pr.waitFor() == 0
    } catch (e: Exception) { false }

    private fun showOverlay() {
        if (!android.provider.Settings.canDrawOverlays(this) || overlay != null) return
        val tv = TextView(this).apply {
            setTextColor(0xFF00FF99.toInt()); textSize = 11f
            setBackgroundColor(0x88000000.toInt()); setPadding(12, 6, 12, 6)
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 16; y = 40 }
        (getSystemService(WINDOW_SERVICE) as WindowManager).addView(tv, lp)
        overlay = tv
        handler.post(stats)
    }

    private fun hideOverlay() {
        handler.removeCallbacks(stats)
        overlay?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) }
        overlay = null
    }

    private fun updateOverlay() {
        val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val temp = (b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val lvl = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        val mi = ActivityManager.MemoryInfo()
        getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
        overlay?.text = "🔋 $lvl%  🌡 ${temp}°C\nRAM boş: ${mi.availMem / 1048576} MB"
    }
}
