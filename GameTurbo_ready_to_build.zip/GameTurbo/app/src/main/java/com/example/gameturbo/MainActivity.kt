package com.example.gameturbo

import android.app.Activity
import android.app.AppOpsManager
import android.app.NotificationManager
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.view.View
import android.widget.*

class MainActivity : Activity() {

    private lateinit var p: SharedPreferences
    private var running = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        p = getSharedPreferences("cfg", MODE_PRIVATE)
        requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(32, 48, 32, 32)
        }
        root.addView(TextView(this).apply { text = "⚡ Game Turbo"; textSize = 26f })

        // İcazələr
        root.addView(title("1. İcazələr"))
        root.addView(btn("İstifadə statistikası (oyunu tanımaq)") {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        })
        root.addView(btn("Ekran üstündə göstərmə (overlay)") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        root.addView(btn("Narahat etməyin rejimi girişi") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        })

        // Funksiyalar
        root.addView(title("2. Funksiyalar"))
        root.addView(sw("Fon proseslərini dayandır", "kill", true))
        root.addView(sw("Bildirişləri blokla (DND)", "dnd", true))
        root.addView(sw("Overlay: batareya / temperatur / RAM", "overlay", true))
        root.addView(sw("Ekran çözünürlüyünü azalt (shell icazəsi lazımdır)", "res", false))
        val sp = Spinner(this)
        val opts = listOf(100, 85, 75, 66)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, opts.map { "$it%" })
        sp.setSelection(opts.indexOf(p.getInt("scale", 85)).coerceAtLeast(0))
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(a: AdapterView<*>?, v: View?, i: Int, id: Long) {
                p.edit().putInt("scale", opts[i]).apply()
            }
            override fun onNothingSelected(a: AdapterView<*>?) {}
        }
        root.addView(sp)

        // Başlat / dayandır
        val start = Button(this)
        start.text = "▶ Başlat"
        start.setOnClickListener {
            if (!hasUsage()) { toast("Əvvəlcə istifadə statistikası icazəsini verin"); return@setOnClickListener }
            val i = Intent(this, BoostService::class.java)
            running = !running
            if (running) startForegroundService(i) else stopService(i)
            start.text = if (running) "■ Dayandır" else "▶ Başlat"
        }
        root.addView(start)

        // Oyun siyahısı
        root.addView(title("3. Oyunları seçin"))
        val games = p.getStringSet("games", emptySet())!!.toMutableSet()
        val pm = packageManager
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        ).filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
        for (a in apps) {
            val pkg = a.activityInfo.packageName
            root.addView(CheckBox(this).apply {
                text = a.loadLabel(pm); isChecked = pkg in games
                setOnCheckedChangeListener { _, c ->
                    if (c) games.add(pkg) else games.remove(pkg)
                    p.edit().putStringSet("games", games.toSet()).apply()
                }
            })
        }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun title(t: String) = TextView(this).apply { text = t; textSize = 18f; setPadding(0, 32, 0, 8) }
    private fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
    private fun sw(t: String, key: String, def: Boolean) = Switch(this).apply {
        text = t; isChecked = p.getBoolean(key, def)
        setOnCheckedChangeListener { _, c -> p.edit().putBoolean(key, c).apply() }
    }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun hasUsage(): Boolean {
        val ao = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        return ao.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) ==
            AppOpsManager.MODE_ALLOWED
    }
}
